**Zutaten:**

- Geriebener Apfel
- Geriebene Möhre
- Trockenobst
- Nüsse
- Kokusmehl
- Zimt