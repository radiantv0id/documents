**Zutaten:**

- Geriebener Kohl (in Zitroneensaft eingeweicht + Cumin)
- Sauce:
    - Gurke
    - Viel frischer Koriander
    - Grüne Chillies
    - Salz und Pfeffer