**Zutaten:**

- Geriebener Kohl (in viel Zitronensaft eingeweicht)
- Geriebene Möhren
- Frühlingszwiebel
- Frischer Koriander
- Cumin
- Rosinen
- Salz