**Zutaten:**

Avocado

- Getrocknete Tomaten
- Blattgrün
- Frühlingszwiebel