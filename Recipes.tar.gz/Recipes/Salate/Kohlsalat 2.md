**Zutaten:**

- Geriebener Kohl
- Zitronensaft
- Kuminpulver
- Korianderpulver
- Geröstete Sesamsamen
- (Rosinen)
- Salz