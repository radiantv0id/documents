**Zutaten:**

- Eingeweichte Datteln
- Spinat (gekocht)
- Geriebene Gurke