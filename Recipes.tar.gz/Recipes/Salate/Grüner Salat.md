**Zutaten:**

- Blattgrün
- Grüne Paprika
- Nüsse
- Tomaten-Möhren-Sauce