**Zutaten:**

- Sprossen
- Avocado
- Miso
- Eisbergsalat