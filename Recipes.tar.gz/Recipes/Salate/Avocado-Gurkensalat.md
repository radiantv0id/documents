**Zutaten:**

- Avocado
- Gurke
- Sprossen
- Sesamsamen
- Sauce:
    - Apfelessig
    - Dattelsirup
    - Cayenne