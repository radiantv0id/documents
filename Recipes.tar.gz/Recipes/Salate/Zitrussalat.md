**Zutaten:**

- Orangen
- Grapefruit
- Granatapfel
- Grüne Trauben