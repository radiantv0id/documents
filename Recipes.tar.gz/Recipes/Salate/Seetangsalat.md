**Zutaten:**

- 50 g Wakame
- 3 EL Sojasauce
- 1 EL Reisessig
- 1 TL Honig
- 1 TL Ingwer
- ½ TL Knoblauch
- ¼ TL Chiliflocken
- 1 Baby-Gurke, dünn geschnitten
- 1 EL Sesamöl
- 1 TL geröstete Sesamsamen