**Zutaten:**

- Okra
- Gurke
- Grüne Paprika
- Frühlingszwiebel
- Nüsse
- Zitronensaft
- Cumin
- Salz