• 400g mushrooms

• Olive oil

• 1⁄4 tsp salt

• 1⁄4 tsp black pepper

• 2 red onions

• 4 garlic cloves

• 2 fresh red chillies

• 30g fresh coriander

• 1 celery stick

• 1 red pepper

• 1 tbsp tomato purée

• 250ml red wine

• 2 tsp soy sauce

• 1 tsp balsamic vinegar

• 2 x 400g tins chopped tomatoes

• 1 x 400g tin black beans

• 1 x 400g tin kidney beans

• 1 1⁄2 tsp maple syrup

• 10g dark chocolate

FOR THE SPICE MIX

• 1 tsp chilli powder

• 1 tsp ground cumin

• 1 tsp smoked paprika

• 1⁄2 tsp ground cinnamon

• 1⁄2 tsp dried oregano

• 1⁄2 tsp salt

• 1⁄2 tsp black pepper

• 1 bay leaf

1.Put the mushrooms in the food processor and pulse until very finely minced (you can chop them if you prefer, but it’s quicker and better with a food processor).

2.Pour a little oil into the hot frying pan. Once the oil is hot, tip in the mushrooms with the salt and pepper and cook for 5 minutes. Take the pan off the heat, transfer the mushrooms to a bowl and set aside.

3.Peel and mince the red onions. Peel and mince the garlic. Rip the stems from the chillies, cut them in half lengthways and remove the seeds if you prefer a milder sauce, then chop finely. Remove the leaves from the coriander and set aside. Finely chop the stalks. Trim the leaves and root from the celery. Cut the pepper in half and cut out the stem and seeds. Cut the celery and pepper into very small chunks.

4.Add a little oil to the large saucepan. Once it is hot, add the minced onions and garlic, the finely chopped coriander stalks and the chillies and cook gently for 5–10 minutes, making sure you stir constantly. Add the chopped celery and red pepper chunks to the pan and stir.

5.Add all the spice mix ingredients to the pan and stir so that the spices are well mixed and coat all the vegetable. Stir in the tomato purée to give a rich colour and depth of flavour. Pour the red wine, soy sauce and balsamic vinegar into the pan and turn up the heat to high. Stir constantly until the liquid has reduced by two-thirds and the alcoholic aroma has subsided. Tip the chopped tomatoes into the pan, stir into the chilli and simmer for 5 minutes, until the sauce is noticeably thicker.

6.Drain the black beans and kidney beans and add them to the pan along with the maple syrup, dark chocolate and the minced mushrooms. Stir everything together really well and then reduce the heat to a very gentle simmer. Leave this bubbling away with the lid off, stirring occasionally until it’s reduced to the right thickness (at least 10 minutes). You can leave it bubbling for longer to deepen the flavours, adding more water if needed to keep the right consistency.

7.Take the lid off the pan and remove the bay leaf. Stir the coriander leaves into the chilli and serve.