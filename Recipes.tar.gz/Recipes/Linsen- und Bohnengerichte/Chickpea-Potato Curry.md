**Ingredients:**

- 500 g chickpeas
- 500 g potatoes
- 100 g cashews
- onion
- leek
- garlic
- ginger
- red chili
- black mustard seeds
- coriander powder
- 2 bay leaves
- lemon juice
- grated coconut