**Ingredients:**

- 2 cups yellow split peas
- 2 cups yogurt / coconut milk
- 1/4 tsp cinnamon
- 1 tbsp coriander
- 2 tbsp sage
- 1 tbsp cumin
- 1 tbsp turmeric
- 1/2 tsp cayenne
- 1 tsp salt
- 1/4 tsp allspice
- 1/2 tsp hing