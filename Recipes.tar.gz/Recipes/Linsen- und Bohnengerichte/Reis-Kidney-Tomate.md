**Zutaten:**

- brauner Reis
- Kidney Bohnen
- Kumin
- Fenchel
- Ingwer
- Kurkuma
- Samber
- 1 Chilie
- Petersilie / Koriander
- Sauce: 2 Tomaten, Knoblauch, Kokosöl