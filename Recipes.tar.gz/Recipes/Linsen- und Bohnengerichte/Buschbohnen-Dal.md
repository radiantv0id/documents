**Zutaten für 1 Person:**

- 3 handvoll Padina Linsen
- 1 handvoll Buschbohnen
- 1 Tomate
- Einige Rosinen
- 1 Zwiebel (in Ringen)
- 2 Knoblauchzehen
- 1/2 Zimtstange
- 5 Curryblätter
- 1/2 TL Ras El Hanout
- 1/2 TL Bockshornklee
- 1/3 TL Schwarze Senfkörner
- 1 TL Kokosöl
- Zitronensaft

**Zubereitung:**

1.  Zwiebel, Knoblauchzehen, Zimt, Bockshornkle, schwarze Senfkörner und Curryblätter in Kokosöl für ein paar Minuten in Kokosöl rösten.
2.  Linsen und Ras El Hanout hinzugeben und rösten bis es gut riecht.
3.  Mit Wasser aufgießen. Sobald es kocht, Buschbohnen und Rosinen hinzugeben.
4.  Für 20+ Minuten auf mittlerer Hitze köcheln lassen.
5.  Nach 15 Minuten Tomaten hinzugeben.
6.  Mit Salz und Zitronensaft abschmecken.