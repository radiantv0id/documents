**Ingredients:**

- Yellow or red lentils
- Onions
- Garlic
- Ginger
- Cumin seeds
- Fennel seeds
- Cinnamon
- Cardamom pods
- Turmeric powder
- Chili powder
- Chopped apricots
- Peanuts
- Grated coconut
- Lemon juice
- Chopped coriander

**Instructions:**

1.  Roast onions, garlic, peanuts and spices in butter.
2.  When the onions become soft add lentils and roast until the scent changes.
3.  Add water and apricots.
4.  Boil until it becomes like a thick soup.
5.  Add grated coconut, lemon juice, coriander and salt.