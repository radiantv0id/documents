**Zutaten:**

- 25 Bananen
- 100 g Rosinen
- 150 g Mandeln
- 150 g Cashews
- 1,5 geraspelte trockene Kokosnuss
- 250 g Mejdool Datteln
- 15 g Kardamomkapseln (Pulver)