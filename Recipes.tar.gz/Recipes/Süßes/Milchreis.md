**Zutaten:**

- Milchreis
- Hafermilch
- Kardamom
- Zimt
- Agavendicksaft
- Apfelsauce + Flohsamen
- etwas Vanille