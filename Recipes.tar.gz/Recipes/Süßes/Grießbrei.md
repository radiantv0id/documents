**Zutaten:**

- Dinkelgrieß
- Hafermilch
- Kokosöl
- Feigen
- Cashews
- Agavendicksaft