**Ingredients:**

- 230 g butter
- 270 g chickpea flour
- 130 g sugar (less!)
- 2 tbsp ground hazelnuts
- 1/2 tsp cinnamon
- 1 tbsp cacao
- 1 tbsp honey

**Instructions:**

1.  Roast chickpea flour in butter for 15 minutes.
2.  Add sugar and let cool down for 15 minutes.
3.  Add hazelnuts, cinnamon, cacao and honey.
4.  Let sit for 1 hour.