**Zutaten:**

Boden
- 1 1/2 Tassen Mandelmehl
- 3 EL geschmolzenes Kokosöl
- 5 Medjool Datteln

„Karamell“
- 1 1/4 Tassen Medjool Datteln
- 1/4 Tassen Nussmus    

Schokolade
- 100 g geschmolzenes Kokosöl
- 25 g Kakaopulver
- 3 EL Agavendicksaft

**Zubereitung:**
1\. Bckform mit Backpapier auslegen.
2\. Alle Boden Zutaten im Food Processor oder Mixer verarbeiten, bis alles gut vermischt ist. Den Teig als Boden in der Form gut pressend auslegen und in Gefrierfach stellen.
3\. In der Zeit „Karamell“ zubereiten: wasche die Küchenmaschine ab und mixe alle „Karamell“ Zutaten, bis alles cremig gemixt ist. Hole die Form aus dem Gefrierfach und lege die „Karamell“ Schicht (am besten mit Silikonspatel\*) ebenmäßig aus. Stelle zurück in den Gefrierfach fürpp 30 Minuten.
4\. Mache die Schokolade oder schmelze die Tafel auf niedriger Hitze. Hole die Form aus dem Gefrierfach raus und begieße mit der Schokolade. Stelle in den Kühlschrank.