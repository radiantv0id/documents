**Ingredients:**

- 1/4 cup maple syrup
- 1/2 cup tahini
- 1 tsp vanilla extract
- optional: 1/3 cup roasted pistachios

&nbsp;

**Instructions:**

Lightly grease a small glass baking dish. You can use a silicone muffin pan if you want. The shape doesn't really matter.

Place the maple syrup in a medium saucepan and heat over medium heat until it reaches 266°F (130°C). The maple syrup will bubble, and some foam will form; this is normal. While the maple syrup is heating, place the tahini, vanilla extract, and pistachios, if using, in another saucepan and warm over low heat. Tahini must be just warm, not hot.

Once the maple syrup has reached the temperature, turn the heat off and pour the warm tahini into the saucepan. Using a wooden spoon, stir until it thickens and doesn't look shiny anymore. You can use an electric beater if you want but do not beat for too long as it thickens very quickly, about 5-10 seconds.

Pour immediately into the prepared dish and spread it into an even layer. Let cool at room temperature for at least 3 hours before removing from the pan or baking dish.

You can then cut it into small squares or make small chunks using your fingers. Enjoy with coffee, tea, or as an afternoon snack!

Halva will keep stored in an airtight container at room temperature for up to 3 weeks.