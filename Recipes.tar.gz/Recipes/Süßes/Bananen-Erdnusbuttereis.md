**Ingredients**

- 3 [medium bananas](https://rstyle.me/+jX4OVQjR1Y1cxjW_kjWXVQ), sliced and frozen
    
- ¼ cup + 2 tablespoons [coconut cream](http://amzn.to/2gswYLE)
    
- ½ cup unsalted, natural creamy peanut butter (more below)
    
- 3 tablespoons [pure maple syrup](https://rstyle.me/+R8klTbDJYzhoP9b5eEFMQQ)
    
- 1 teaspoon [pure vanilla extract](https://rstyle.me/+EV5OhkZqB6MbiZcN5_AbOw), optional