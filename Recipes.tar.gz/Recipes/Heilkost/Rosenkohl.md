**Zutaten:**

- Gedünsteter Rosenkohl
- Nüsse oder Acocado
- Optional: gebackene Tomatenscheiben