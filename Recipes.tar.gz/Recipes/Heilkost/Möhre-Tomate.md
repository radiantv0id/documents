**Zutaten:**

- Gekochte und pürierte Möhre / Beete
- Tomatensauce: Tomaten, 1 EL Erdnussbutter, 2 Knoblauchzehen, S+P