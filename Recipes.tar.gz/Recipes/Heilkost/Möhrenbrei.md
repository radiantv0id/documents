**Zutaten:**

- Brei:
    - Möhren (x)
    - Knoblauch (x)
    - Kokosöl
- Mungsprossen
- frischer Koriander
- Gebratener Spinat