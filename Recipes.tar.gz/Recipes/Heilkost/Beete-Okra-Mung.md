**Zutaten:**

- Beetebrei (x)
- Okra
- Mungsprossen
- Kokosöl
- Sauce:
    - Tomaten
    - Datteln
    - Viel frischer Koriander
    - Knoblauch
    - Salz und Pfeffer