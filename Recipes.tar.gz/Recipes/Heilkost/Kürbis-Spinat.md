**Zutaten:**

- Kürbis (x)
- Spinat (x)
- Sauce a):
    - Tomaten
    - 2 Knoblauchzehen
    - Viel frischer Koriander
    - Erdnussbutter (verdünnt)
    - Salz und Pfeffer
- Sauce b): Munghumus