**Zutaten:**

- Möhrenbrei
- Mungsprossen
- Salat
- Sauce:
- Tomaten
- Viel frischer Koriander
- Erdnussbutter
- Zitronensaft
- Knoblauch
- Kumin
- Pfeffer