**Zutaten:**

- Geriebener Kohl
- Buschbohnen (x)
- Geriebene Zwiebel
- Sauce:
    - Tomaten
    - Tahini
    - Zitronensaft
    - Cayenne
    - Salz und Pfeffer