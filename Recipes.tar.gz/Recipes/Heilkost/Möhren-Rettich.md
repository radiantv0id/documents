**Zutaten:**

- Möhren (x)
- Rettich
- Tomatensauce