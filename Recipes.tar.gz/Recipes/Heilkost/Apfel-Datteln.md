**Zutaten:**

- Geriebener Apfel (roh) / gekochtes Apfelpürre
- Eingeweichte Datteln
- etwas Zitrone
- Zimt