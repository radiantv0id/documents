**Zutaten:**

- Zerdrückte Bananen
- Eingeweichte Datteln