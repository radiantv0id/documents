**Zutaten:**

- Geriebene Beete
- Mungsprossen
- Rosinen
- Tomatensauce