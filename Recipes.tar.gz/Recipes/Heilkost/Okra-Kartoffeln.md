**Zutaten:**

- Kartoffeln (x)
- Okra
- Sauce:
- Tomaten
- Frühlingszwiebel
- Frischer Koriander
- Cumin
- Pfeffer