**Zutaten:**

- Kürbis (x)
- Algen
- Rosinen
- Sauce:
    - Gurke
    - Frischer Koriander
    - Tahini
    - Kumin
    - Salz und Pfeffer