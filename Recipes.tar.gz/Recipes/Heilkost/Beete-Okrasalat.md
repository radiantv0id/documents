**Zutaten:**

- Geriebene Beete
- Okra
- Grüne Paprika
- Rosinen
- Salz und Pfeffer