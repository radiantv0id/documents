**Zutaten:**

- Apfel
- Birne
- Minze