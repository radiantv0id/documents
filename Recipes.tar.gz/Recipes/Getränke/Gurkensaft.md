**Zutaten:**

- Gurke
- Zitrone
- optional: Kala Namak