**Zutaten:**

- 2 kg Rinderknochen mit Mark
    
- 1 Scheibe Knollensellerie
    
- 1 Stange Lauch
    
- 2 Stk Karotten
    
- 1 Stk Zwiebel gelb
    
- 2 Stk Lorbeerblätter
    
- 1 TL Wacholderbeeren
    
- 1 TL Pfefferkörner
    
- 2-3 TL Rosa Himalaya Salz
    
- 4,5 l Wasser
    
- 1-2 EL Apfelessig