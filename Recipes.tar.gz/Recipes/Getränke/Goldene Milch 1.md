**Zutaten:**

- 1 Tasse Hafermilch
    
- 1 EL Kurkuma
    
- ½ TL Zimt
    
- ¼ TL Pfeffer
    
- Prise Muskat
    
- Honig
    

**Zubereitung:**

1.  Gewürze in Kokosmus rösten.
    
2.  Hafermilch hinzugeben und für 5 Minuten köcheln lassen.
    
3.  Mit Honig süßen.