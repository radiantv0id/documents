**Zutaten:**

- 2 EL Leinsamen (1-2 Stunden eingeweicht) oder 2 EL Mandelmus
- 300-400 ml Wasser
- 1 cm Ingwerwurzel
- 1 Würmchen frische Kurkuma oder 1 EL Kurkuma-Pulver
- 1-3 TL Xylit
- eine Prise schwarzer Pfeffer
- 1/2 TL Zimt
- 1 TL natives Kokosöl für cremige Konsistenz

&nbsp;

\-> entzündungshemmend, antioxidativ, immunsystemstärkend, regt die Leberfunktion an