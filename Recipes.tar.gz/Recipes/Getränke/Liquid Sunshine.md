**Zutaten:**

- Pinke Grapefruit
- Orange
- Blutorange
- Manderine
- Zitrone