**Zutaten:**

- 2 Kurze Wodka
- 2 Kurze Kassakenkaffee
- 4 Kurze Hafermilch
- 2 TL Ahornsirup
- Vanille
- Eis