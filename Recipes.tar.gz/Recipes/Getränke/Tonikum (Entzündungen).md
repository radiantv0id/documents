**Zutaten für 4 Tassen:**

- 2 Tassen Wasser
    
- 2 Beutel grüner Tee
    
- 5 Zweige Tyhmian
    
- 5 cm Ingwer
    
- 5 cm Kurkuma
    
- 1 EL Honig
    
- 1 EL Apfelessig
    
- Eiswürfel
    
- 2 Tassen Wasser
    

**Zubereitung:**

1.  Wasser zum Kochen bringen, alle Zutaten hinzugeben und für 15 Minuten ziehen lassen.
    
2.  Für 1 Stunde in den Kühlschrank stellen.
    
3.  Glass zur Hälfte mit Eis füllen. ½ Tasse Tonikum + ½ Tasse Wasser