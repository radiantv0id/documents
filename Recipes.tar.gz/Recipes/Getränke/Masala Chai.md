**Zutaten:**

- Kardamom
- Zimt
- Ingwer
- Süßholz
- Nelken
- Sternanis
- Fenchel
- Schwarzer Pfeffer
- Pippali