**Zutaten für 4 Portionen:**

- 50 g frischer Ingwer
- 50 g frischer Kurkuma
- 1 Zitrone
- 1/2 TL Pfeffer
- 0,1 - 0,2 l Wasser

Nach dem pürieren hinzugeben:

- 2 gehäufte TL Hagebuttenpulver
- 4 TL Agavendicksaft

&nbsp;

\-> 0,1l für 8