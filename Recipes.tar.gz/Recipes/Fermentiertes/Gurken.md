**Zutaten:**

- Gurken
- Dill
- 1 Eichenblatt (-> erhält Bissfestigkeit)
- 2 Knoblauchzehen
- 1 gehäufter EL Salz pro Liter Wasser