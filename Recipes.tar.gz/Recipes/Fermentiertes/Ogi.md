**Zutaten:**

- Hirse
- Knoblauch
- Butter
- Petersilie