**Ingredients**

- 1 head napa or savoy cabbage
- Salt
- Vegan fish sauce:
    - 2 tbsp soy sauce
    - 2 tbsp sugar
    - ¼ cup pineapple juice
    - ¼ cup water
- Chili sauce:
    - 3 tbsp ginger
    - 1 head garlic
    - 1 small white onion
    - ½ cup chili flakes
- Vegetables:
    - 2 carrots
    - 6 green onions
    - radish