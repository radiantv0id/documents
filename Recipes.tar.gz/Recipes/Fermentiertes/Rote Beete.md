**Zutaten:**

- 2 EL Radieschen
- 1 TL getrockneter Dill