**Zutaten für 1 Person:**

- 1 mittelgroße Süßkartoffel
- 1 1/2 Bananen
- 1/2 Dose Kokoscreme
- walnussgroßes Stück Ingwer
- Tomatenmark
- Ras el hanout
- Chili