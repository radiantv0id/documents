**Zutaten für 2 Personen:**

- 200g Feta
    
- 200 g Rucola / Spinat
    
- 1 große Tomate
    
- 2 Knoblauchzehen
    
- Kokosöl
    

\+ Hirsebrei