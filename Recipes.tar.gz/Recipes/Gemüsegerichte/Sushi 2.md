**Zutaten:**

- "Reis":
    - Geriebener Rettich (ausgeprest) oder Blumenkohl
    - 1/2 Tassen eingeweichte Samen
    - Lauchzwiebel
    - Salz
    - Kokosöl
- Gurke
- Avocado
- Sprossen
- Optional: Erdnusssauce