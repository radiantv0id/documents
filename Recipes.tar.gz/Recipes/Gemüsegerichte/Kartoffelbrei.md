**Zutaten:**

- Festkochende weiße Kartoffel / Süßkartoffeln
- Viel (!) Knoblauch
- Viel (!) Olivenöl

**Zubereitung:**

1.  Kartoffeln schälen und vierteln.
2.  In einen Topf mit kochendem Wasser geben.
3.  Knoblauch und Olivenöl hinzugeben und pürieren bis eine schleimige Konsistenz entsteht.
4.  Mit Salz und Pfeffer abschmecken.
5.  Optional: Mit gebratenen Zwiebeln und Petersilie garnieren.