**Zutaten:**

- Zwiebeln
    
- Rote Paprika
    
- Tomaten (weniger als Paprika)
    
- Paprikapulver
    
- Majoran
    
- Liebstöckel
    
- Kokosöl