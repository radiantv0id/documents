**Zutaten für Variante 1:**

- 250 g Okra
    
- 3 EL Ghee
    
- 1/2 Kuminsamen
    
- 1/2 TL schwarze Senfkörner
    
- 1/2 TL Sesamsamen
    
- 3 getrocknete rote Chillies
    
- 5 Curryblätter
    
- 1 TL Chilliepulver
    
- 1/4 TL Kuminpulver
    
- 1/4 TL Kurkumapulver
    
- 4 Knoblauchzehen
    

&nbsp;

**Zutaten für Variante 2:**

- Okras
- 1 Tomate
- Knoblauch
- Kuminsamen
- (Methi)
- Kuminpulver
- Kurkumapulver
- Salz