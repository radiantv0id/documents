**Zutaten:**

- Süßkartoffel
- Tomaten
- Zwiebel
- Kokosöl
- Cayenne
- Ingwer
- Pfeffer