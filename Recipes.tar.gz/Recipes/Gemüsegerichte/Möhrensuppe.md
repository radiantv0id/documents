**Zutaten für 4 Personen:**

- 400 g carrots
- 2 onions
- 2 cloves of garlic
- 2 walnut-sized pieces of ginger
- 2 tbsp butter
- 4 tsp curry
- 4 tbsp peanutbutter
- 300 ml coconut milk
- 500 ml water
- 2 tbsp lemon juice
- Salt and pepper

**Instructions:**

1.  Roast onions, garlic and ginger in butter.
2.  Add all ingredients apart from lemon juice.
3.  When the carrots are well cooked blend.
4.  Add lemon juice, salt and pepper.