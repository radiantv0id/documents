**Zutaten für 2 Personen:**

- 6 Tassen Dashi / Gemüsebrühe
    
- 1,5 Blätter Nori / Wakame
    
- 5 EL Misopaste
    
- 1 Tasse Spinat
    
- 1 Tasse Frühlingszwiebel
    
- 200 g Seidentofu / Tofu
    

**Zubereitung:**

1\. Dashi / Gemüsebrühe zum Köcheln bringen.

2\. In the meantime, place miso (starting with lesser end of range) into a small bowl, add a little hot water and whisk until smooth. This will ensure it doesn’t clump when added to the soup later. Set aside.

3\. To the broth add chard (or other greens of choice), green onion, and tofu (if using silken, add at the end of cooking) and cook for 5 minutes. Then add nori and stir. Remove from heat, add miso mixture, and stir to combine.

4\. Taste and add more miso or a pinch of sea salt if desired. Serve warm. Best when fresh.