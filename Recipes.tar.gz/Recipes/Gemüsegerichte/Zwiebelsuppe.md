**Zutaten:**

- Zwiebeln mit Zucker anbraten
- Sellerie und Möhre dazu
- Hafercuisine
- Petersilie