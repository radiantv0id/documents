Zutaten für 4 Portionen:

- 1-2 Bünde Farn
- 2 EL Ghee
- 1/4 TL Methi
- 2 grüne Chillies
- 2 Knoblauchzehen
- 1 1/2 TL frischer Ingwer
- 1/4 TL Kurkuma
- 1/2 TL Kumin
- 1/2 TL Koriander