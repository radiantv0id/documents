**Zuttaten:**

- Möhren
- Kohl
- Bohnen
- Kokos
- Senfknörner
- Öl
- Urad