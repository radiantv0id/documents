1 mittelgroße Zwiebel, in dünne Scheiben geschnitten

2 Esslöffel Speckfett, oder Öl

500 g Paprika, z. B. ungarische Wachspaprika, Bananenpaprika, italienische Paprika oder grüne Paprika, in 1/4-Zoll-Streifen geschnitten

3 große reife, geschälte und in Stücke geschnittene Tomaten, oder verwenden Sie die folgende Abkürzung

1 1/2 Teelöffel Zucker

1 1/2 Teelöffel Salz

1 Esslöffel süßes ungarisches Paprikapulver

(+ Weißweinessig)

Methode

In einer großen Pfanne die Zwiebel in Speckfett oder Öl bei schwacher Hitze 5 Minuten anbraten.

Paprikastreifen hinzufügen und weitere 15 Minuten braten.

Tomaten, Zucker, Salz und Paprika hinzufügen und weitere 25 bis 30 Minuten unter gelegentlichem Rühren kochen, bis die Mischung eine stückige Tomatensauce ergibt.