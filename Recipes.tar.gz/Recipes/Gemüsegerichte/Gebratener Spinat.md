**Zutaten:**

- Spinat
- Zwiebel
- Knoblauch
- Ingwer
- Rote Chillies
- Sesamöl
- Salz