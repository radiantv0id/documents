**Zutaten:**

- 2 mittelgroße Süßkartoffeln
- 1/3 Kohl
- 1 handvoll Buschbohnen
- 2 Knoblauchzehen
- 1/2 TL Fenchel
- 1 TL Bockshornkleesamen
- 1/2 Zimtstange
- 1 TL Jaffna Curry
- 1/2 TL Chilipulver
- 1 Tasse Kokosmilch
- Frischer Koriander
- Zitronensaft
- Kokosöl