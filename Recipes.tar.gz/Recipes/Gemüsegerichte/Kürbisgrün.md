**Zutaten:**

- Kürbisgrün
- Ghee
- Methi
- Getrockneten Chillies
- Knoblauch
- Ingwer
- Kurkuma
- Kumin