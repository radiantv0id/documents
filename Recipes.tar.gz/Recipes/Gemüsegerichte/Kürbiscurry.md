**Ingredients:**

- 1/2 hoccaido pumpkin
- 1/2 cup coconut milk
- 1 tsp cumin seeds
- 3 dried chilies
- 1 tbsp ginger
- 1/2 onion
- 1 tsp cumin powder
- 1 tbsp coriander powder
- 1/2 tsp turmeric
- 2 tomatoes
- 1 tbsp honey
- 1/4 cup fresh coriander

**Instructions:**

1.  Chop pumpkin and bake in the oven with olive oil, salt and pepper for 30 minutes.
2.  Roast onion and spices.
3.  Add coconut and let boil until half of the volume has evaporated.
4.  Add pumpkin and tomatoes and cook for 5 minutes.
5.  Add honey and coriander.