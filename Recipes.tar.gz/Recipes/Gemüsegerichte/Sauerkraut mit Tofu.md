**Zutaten:**

- Sauerkraut
- rote Zwiebel
- Nelken
- Lorbeer
- Tofu