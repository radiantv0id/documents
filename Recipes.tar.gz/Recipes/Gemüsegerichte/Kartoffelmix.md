**Zutaten:**

- Kartoffel
- Süßkartoffel
- Kohl
- Kokosmilch
- Knoblauch
- Chili
- Bockshornklee
- Frischer Koriander