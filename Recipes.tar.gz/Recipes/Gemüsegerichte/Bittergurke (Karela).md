**Zutaten:**

- Karela
- Panch Phoron
- Kurkumapulver
- Kuminpulver
- Zitronensaft
- Ghee
- Salz