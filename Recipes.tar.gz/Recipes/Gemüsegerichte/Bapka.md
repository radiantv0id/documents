**Ingridients six servings:**

- 1 kg grated potatoes
- 1,5 cups chopped onion
- 2 eggs
- (200 g mushrooms)
- 1/2 tsp salt
- 1/4 tp pepper
- 1/3 cup flour
- 1-2 tsp fresh herbs

**Instructions:**

1\. Bake for 90 minutes.