**Ingrdients:**

- 1 cup chopped onion
- 1 tsp ginger
- 1/2 tsp curry powder
- 1/4 tsp ground cumin
- 1/4 tsp nutmeg
- 2 cloves garlic
- 2 cups sweet potato
- 1 cup coconut milk
- 0,5 kg pumpkin
- 1 1/2 cups water