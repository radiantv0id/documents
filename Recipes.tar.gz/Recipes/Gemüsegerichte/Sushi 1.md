**Zutaten:**

- Möhrenstreifen
- Gurkenstreifen
- Avocado
- Gekochte Sauce:
- Viel Frühlingszwiebel
- Knoblauch
- Datteln
- Pflaumen
- Zitronensaft
- Salz und Pfeffer