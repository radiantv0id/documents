Zutaten:

- Farn
- Spinat
- Knoblauch
- Kumin
- Rosinen
- Zitronensaft
- Salz