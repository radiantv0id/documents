### Ingredients
-  ¼ cup chia seeds + 1,5 cups water
- 2 tbsp nut butter
- 500 g buckwheat flour
- 3 tsp baking powder
- 1 tsp salt
- 0,5 cup water

### Instructions
- Pre-heat ovent o 180° C.
- In a medium bowl, combine the chia seeds with the water (1 ½ cup) and let it sit for 10-15 minutes.
- In a large bowl, combine the buckwheat flour, sunflower seeds, baking powder and salt.
- Once the chia-water mixture is done resting (it should look like a gel), then add the almond butter to it and whisk to combine. Make sure it is super smooth and creamy with no nut butter lumps anymore.
- Transfer the chia-nut butter mixture to the buckwheat flour bowl along with the extra 1 cup of water and stir using a spatula. Try not to overmix and scrape the sides and bottom of the bowl to make sure there are no dry areas anymore. The dough should be thick and sticky.
- Transfer to the prepared loaf pan and cook for 1 hour 20 minutes. Let the bread cool down for a few hours before slicing (it will keep setting as it cools down).