**Zutaten für 4 Personen:**

- 1 cup flour
- 1 small onion
- 3 tbsp grated coconut
- 1/2 grated carrot
- 2 green chilies
- 2-3 tbsp coriander leaves
- 1/2 tsp cumin
- 1/2 tsp ginger
- salt