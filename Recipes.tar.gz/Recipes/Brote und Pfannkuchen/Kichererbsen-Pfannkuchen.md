**Zutaten für 3 Personen:**

- 1 cup chickpea flour
- 1 tsp baking soda
- ¾ cup oat milk
- 1 egg
- 1 tbsp olive oil
- 1 mashed banana
- ¾ cup berries