**Ingredients for 8 pieces:**

½ cup warm water

2 tsp dy yeast

2 3/4 cups flour

½ cup yoghurt

½ tsp salt

1 tbsp oil

**Instructions:**

1\. Mix yeast and warm water and let it sit for 10 minutes.

2\. Add the rest of the ingredients and knead the dough for 10 minutes.

3\. Let sit for 1 hour.

4\. Cut the dough into 8 pieces.

5\. Roast on medium heat and without oil in a pancake pan.

5\. Add butter and minced garlic.