**Zutaten:**

- 1 Tasse Mungsprossen
- 2 Knoblauchzehen
- 2 EL Zitronensaft
- 2 EL Tahini / Erdnussbutter
- Cayenne
- Salz