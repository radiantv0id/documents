**Zutaten:**

- 1 Tasse Mungsprossen
- 1 rote Beete
- Frischer Koriander
- Zitronensaft
- Optional: Sesamöl oder Tahini