Tomaten, 2 Datteln, Knoblauch, ACV, Cayenne
Tahini, ACV, Agave
2 Erdnuss, 2 ACV, 1 Miso, 2 Agave, +3 Wasser