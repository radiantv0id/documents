**Variante 1:**

- Tomaten
- Knoblauch
- Viel frischer Koriander
- Datteln
- Zitrone
- Salz und Pfeffer

&nbsp;

**Variante 2:**

- 2 Tomaten
- 2 EL Erdnussbutter
- 3 Datteln
- Zitronensaft
- Cayenne
- Ingwerpulver
- Salz

&nbsp;

**Variante 3:**

- Tomate
- Rettich
- Knoblauch
- Zitronensaft
- Frischer Koriander
- Salz und Pfeffer

&nbsp;

**Variante 4:**

- Tomaten
- Knoblauch
- Feigen
- Frühlingszwiebel
- Sonnenblumenkerne
- Cayenne