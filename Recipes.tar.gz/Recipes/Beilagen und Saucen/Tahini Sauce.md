**Ingredients for 4 people:**

- 6 cloves of garlic
- 3 tbsp olive oil
- ½ cup tahin
- 1 cup oat milk
- Juice of 1 lemon
- One handful ground almonds
- Salt and pepper

**Instructions:**

1.  Roast minced Garlic in olive oil.
2.  Add tahin, oat milk and ground almonds.
3.  Boil until consistency is creamy.
4.  Add lemon juice, salt and pepper.