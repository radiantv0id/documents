**Zutaten:**

- Avocado
- Zwiebel
- etwas Zitronensaft
- Tomatenstücke
- Cayenne
- Salz und Pfeffer