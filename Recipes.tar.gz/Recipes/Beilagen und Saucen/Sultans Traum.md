**Ingredients for 2 people:**

- 10 dates
- 3 tbsp olive oil
- 1 tbsp honey
- 1 tbsp curry powder
- 300 g feta
- Yoghurt

**Instructions:**

1.  Chop dates.
2.  Mix olive oil with honey and curry powder.
3.  Mix everything with feta and a bit of yoghurt.
4.  Serve with naan.