1 (15-ounce) can chickpeas, drained or 1 ½ cups cooked chickpeas (250g)

¼ cup fresh lemon juice, from 1 large lemon (60ml)

¼ cup well-stirred tahini

1 small garlic clove, minced

2 tablespoons extra-virgin olive oil, plus more for serving (30ml)

½ teaspoon ground cumin

Salt to taste

2 to 3 tablespoons cold water or aquafaba (45ml)

Dash ground paprika, sumac, or Za’atar for serving