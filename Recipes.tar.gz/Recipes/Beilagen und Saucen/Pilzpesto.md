**Zutaten für 2 Personen:**

- 200 g Pilze
    
- 4 EL Walnüsse
    
- 1 Knoblauchzehe
    
- 2 EL Misopaste
    
- 1 handvoll Petersilie
    
- etwas Zitronensaft
    
- 1 EL Olivenöl
    

**Zubereitung;**

1.  Alle Zutaten zusammen pürieren.
    
2.  Mit Salz und Pfeffer abschmecken.