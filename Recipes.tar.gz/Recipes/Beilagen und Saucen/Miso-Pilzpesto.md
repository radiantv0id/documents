**Zutaten:**

- Miso
- Pilze
- Paprika
- Walnüsse
- Koriander / Petersilie
- Knoblauch
- Zitrone