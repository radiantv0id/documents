**Zutaten:**

- 1 große Zwiebel
- 2 große rote Paprika
- 8 mittelgroße Tomaten

**Zubereitung:**

1.  Gemüse in einem vorgeheizten Ofen für 45 – 60 Minuten backen.
2.  Alles pürieren.

\-> Als Salatdressing, Dip oder Sauce für gebackenes Gemüse verwenden.