**Zutaten:**

- Tomaten
- viel Tahini
- (Zwiebel)
- Salz und Pfeffer