**Zutaten:**

- Brennnesseln
    
- Walnüsse
    
- Knoblauch
    
- Olivenöl
    
- Salz