**Ingredients:**

- Yoghurt
- Finely chopped cucumbers
- Finely chopped tomatoes
- Finely chopped onions
- Mint
- Lemon juice
- Cumin powder
- Salt