**Ingredients:**

- ½ teaspoon rapeseed oil (optional)
- ½ cup sesame seeds
- ½ cup urad dhal
- ½ cup channa dhal
- 1/2 tsp turmeric
- 1/4 tsp asafoetida
- A large handful of dried Kashmiri chillies
- 30 fresh curry leaves
- Salt to taste

**Instructions:**

1.  Using the oil, add it to a pan over low heat. The oil isn't necessary but speeds up the dry frying. You will need to soak up the oil with paper towels before grinding!
2.  Dry fry the ingredients separately, as shown over low heat or all together.
3.  When roasted as photographed, you need to let the ingredients cool.
4.  Then, grind to a powder. This is not a really fine powder but it is still quite fine.
5.  Season with salt to taste and use as required. I'm sure that once you try it, you'll think of a lot of good and perhaps even unique uses!