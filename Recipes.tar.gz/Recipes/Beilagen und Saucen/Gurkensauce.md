**Variante 1**

- Gurke
- Minze
- 1-2 Knoblauchzehen
- 4 Datteln
- (Samen)
- Zitrone
- Pfeffer

&nbsp;

**Variante 2:**

- 2 Gurken
- 1 Tasse eingeweichte Mandeln
- Frischer Fenchel
- Frische Minze
- 1-2 Knoblauchzehen
- Saft von 1-2 Zitronen
- Pfeffer

&nbsp;

**Variante 3:**

- Geschälte Gurke
- Viel frische Minze
- Zitronensaft
- Optional: Datteln

&nbsp;

**Variante 4:**

- 1 große geschälte Gurke
- 1-2 Knoblauchzehen
- Zitronensaft
- Frische Minze / frischer Koriander
- Salz und Pfeffer
- Optional: 1/2 Tasse eingeweichte Samen