**Zutaten:**

- 70 g Linsen
- 5 getrocknete Tomaten
- 1 EL Tahini
- 1 EL Wasser
- 1/2 TL Cumin
- 1/2 TL Samber
- 1/2 TL Paprika
- Safter 1/4 Zitrone
- Salz