**Variation 1 ingredients:**

- 1 Tbsp miso
    
- 3 Tbsp peanut butter
    
- 2 Tbsp water
    
- ½ Tbsp apple cider vinegar
    
- ½ Tbsp sesame oil
    
- ½ tsp maple syrup
    
- 1 tsp minced ginger
    

&nbsp;

**Variation 2 ingredients:**

• 3/4teaspoonlight olive oil

• 3clovesminced fresh garlic

• 1/2cupunseasoned rice vinegar

• 2tablespoonslow-sodium tamari, or low-sodium soy sauce

• 1/3cupsambal oelek

• 1cuporange marmalade, use sugar free for low-carb version!

**Instructions:**

• In a medium skillet, sauté the garlic in the olive oil for 1 to 2 minutes over medium heat or until softened and aromatic.

• Whisk in the rice vinegar and tamari. Simmer for 4 to 6 minutes.

• Then whisk in the sambal oelek and simmer for 2 to 3 minutes. Lastly stir in the marmalade and simmer for 5 more minutes before allowing to cool completely and storing in an air-tight container.

Keep refrigerated for 2 to 4 months or longer. This can also be frozen.