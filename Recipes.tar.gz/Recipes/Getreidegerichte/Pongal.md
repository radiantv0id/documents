**Zutaten für 1 Person:**

- 2 handvoll Basmati Reis
    
- 1 handvoll rote Linsen
    
- ½ TL Kreuzkümmelsamen
    
- etwas Asafötida
    
- 1 TL geriebener Ingwer
    
- 8 ganze Pfefferkörner
    
- ein paar Curryblätter / Lorbeerblätter
    
- einige Cashews
    
- 1 TL Kokosöl
    

**Zubereitung:**

1.  Kreuzkümmelsamen, Pfefferkörner und Curryblätter für ein paar Minuten in Kokosöl rösten.
    
2.  Reis, Linsen und Hing hinzugeben und rösten bis es gut riecht.
    
3.  Mit Wasser aufgießen und 20+ Minuten auf mittlerer Hitze köcheln.
    
4.  Den Reislinsen-Eintopf pürieren und für 20 Minuten stehen lassen, sodass er andickt.
    
5.  Cashews in einer Pfanne ohne Öl rösten und dazugeben.
    
6.  Mit Salz abschmecken.