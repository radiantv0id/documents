Zutaten für 1 Person:
* 1/2 Tasse Sushireis
* 2 Noriblätter
* 100 g Tofu
* etwas Gurke
* Mungbohnensprossen
* gepickelte Radieschen
* Reisessig
* Agavendicksaft
* Erdnussbutter

Zubereitung:
1. Reis kochen und 15 Minuten ziehen lassen.
2. Radieschen pickeln: 1/2 Reisessig + 1/2 Tasse Wasser + 1 EL Agavendicksaft + 1/2 TL Salz zum Kochen bringen. ÜBer dünn geschnittene Radieschen gießen und stehen lassen.
3. Erdnusstofu: 1/2 El Reisessig + Miso +1 EL Agavendicksafe + 1 EL Erdnussbutter + feingehackten Knoblauch gut vermischen. Tofu braten und danach mit Sauce bedecken.