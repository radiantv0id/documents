**Ingredients for 3 people:**

- 1 1/2 cups rice
- 2-3 tbsp lemon juice
- 1/2 tsp salt
- 3/4 tsp mustard seeds
- 4 tbsp peanuts or cashews
- 1/2 tsp turmeric
- 2 green chilies
- 1 sprig curry leaves
- 1 tsp chana dal
- 1 tsp urad dal
- 1 pinch hing
- 1/2 tbsp ginger
- coconut powder
- sesame oil