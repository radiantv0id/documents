**Zutaten:**

- 2 Teile Jasminreis
- 1 Teil gelbe Linsen
- Spinat
- Tomaten
- Rosinen
- Erdnüsse
- Koriandersamen
- Kreuzkümmelsamen
- Schwarze Senfkörner
- Curryblätter
- Zimtstange
- Hing
- Kurkuma
- Chiliflocken
- Zitronensaft
- Kokosraspeln
- Kokosöl