**Ingredients:**

- ½ cup split yellow mung beans
- ½ cup white basmati rice
- 2 tsp cumin seeds
- 2 tsp coriander powder
- ¼ teaspoon black mustard seeds
- 1½ tbsp ginger (crushed)
- A pinch of hing (asafoetida)
- 1 tsp turmeric
- 2 tablespoons oil
- 4 cups water
- 1 lemon
- 2 tbsp coriander leaves (chopped finely)
- Salt

**Instructions:**

1.  Soak the mung beans in water overnight and drain the water the next morning.
2.  Rinse the rice well.
3.  Heat the oil in a pan on medium heat.
4.  Then, add the black mustard seeds, fenugreek, and cumin.
5.  After 3-4 minutes, add the turmeric, coriander powder, ginger, and asafoetida.
6.  Add the mung beans, rice as well as water.
7.  Put a lid on it and lower the heat.
8.  Let it cook for about 45 minutes; stir from time to time.
9.  Adjust the water content according to how thick you want the khichdi to be.
10. Then once ready, add salt, freshly squeezed lemon juice and the coriander.