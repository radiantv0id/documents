**Ingredients (2 cups):**

- 1/2 teaspoon cumin seeds, whole
- 1/2 teaspoon brown mustard seeds, whole
- 1/4 teaspoon freshly ground black pepper
- 1 teaspoon Vata Churna
- 2 tablespoons shredded coconut
- 1/8 teaspoon cayenne pepper
- 7 cups bone, chicken, or vegetable broth (substitute with water)
- 1/4 cup minced onion
- 2 tablespoons finely minced fresh ginger
- 2 tablespoons sesame oil
- 2 cinnamon sticks
- 1 lemon