**Ingredients:**

- 1:1 basmati rice (or any other grain) and red / yellow lentils
- Dal spices
- Mixed vegetables
- Grated coconut
- Lemon juice
- Optional: Chopped coriander

**Instructions:**

1.  Proceed as with dal.
2.  Add chopped vegetables when the water is boiling.