**Zutaten für 1 Person:**

- 2 handvoll Hirse
- ½ Süßkartoffel
- 8 Datteln
- handvoll Mungsprossen
- 4 Pfefferkörner
- 3 Kardamomkapseln
- 4 Nelken
- ½ TL Kreuzkümmelsamen
- etwas Kurkuma
- ein paar Korianderblätter
- Zitronensaft einer halben Zitrone
- 1 TL Kokosöl

**Zubereitung:**

1.  Kardamom, Nelken, Kreuzkümmel und Korianderblätter in Kokosöl rösten.
2.  Hirse und Kurkuma hinzugeben und rösten.
3.  Mit Wasser aufgießen und Süßkartoffel und Datteln hinzugeben.
4.  Mungbohnensprossen unterrühren.
5.  Zitronensaft hinzugeben, salzen und ziehen lassen.