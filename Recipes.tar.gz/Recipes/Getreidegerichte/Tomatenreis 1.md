**Ingredient for 4 people:**

- 3 cups rice
- 4 tbsp ghee
- 2 onions
- 2 green chilies
- 2 tbsp ginger garlic paste
- 2 cup tomatoes
- 2 tsp garam masala
- 2tsp chili powder
- 1/2 tsp turmeric
- 2 bay leaves
- 1 1/2 tsp cumin seeds
- 2 inch cinnamon
- 6 cardamom pods
- 6 cloves
- 6 tbsp coriander leaves
- 2tbp lemon juice
- 24 cashews
- 1 1/2 tsp salt

**Instructions:**

1.  Roast spices.
    
2.  Add tomatoes.
    
3.  Add water and rice.