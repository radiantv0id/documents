**Ingredients for 4 people:**

- 2 cups / 400g basmati rice
- 3 carrots (7oz / 200g)
- 1/2 cup / 80g brown raisins 
- 1 onion
- 5 cloves garlic
- 3 tbsp sesame oil
- 3 tbsp vegetable oil
- 2 tbsp butter
- 3 tsp cumin powder
- 3 tsp sugar
- 2 tsp cumin powder
- 1 1/2 tsp cardamom powder
- 1 tsp turmeric
- 1 tsp ground garam masala
- 1/2 tsp black pepper
- 2 tbsp salt + extra to taste
- 1/4 tsp ground saffron
- 3 ice cubes (for blooming the saffron)
- 1 tbsp slivered pistachios as garnish (optional)

**Instructions:**

1.  Make saffeon water
    
2.  Fry onions andngarlic, add spices > sauce
    
3.  Caramelize carrots, fry raisins for 30 secs
    
4.  Rinse rice 3-4 times (removes rise starch > fluffier and less sticky)
    
5.  Mix boiled rice with ground spices