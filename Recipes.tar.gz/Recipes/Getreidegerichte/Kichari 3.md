**Zutaten:**

- 1 Tasse Basmatireis
- 1/2 Tasse gelbe Mungbohnen
- 3 EL Ghee
- 1 TL schwarze Senfkörner
- 2 Prisen Asafötida
- 1 TL Kreuzkümmel-Samen
- 1/2 TL Kurkuma
- 1/2 TL Salz
- 4 Tassen Wasser