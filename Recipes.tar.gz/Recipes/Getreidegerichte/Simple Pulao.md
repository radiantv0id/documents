**Zutaten:**

- Brauner reis
- 2 Nelken
- 2 Kardamomkapseln
- Zimtstange
- Cuminpulver
- Garam Masala
- Kokosöl
- Mungsprossen
- geriebene Möhren