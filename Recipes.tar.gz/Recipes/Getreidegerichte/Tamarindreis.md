**Ingredient for 2 people:**

- 1 cup rice
- 4 tbsp tamarind
- 2 tbsp jaggery
- 1/2 tsp salt
- tempering:
    - 1/2 tsp mustard seeds
    - 3 tbsp peanuts
    - 1/2 tbsp chana dal
    - 1/2 tbsp urad dal
    - 1-2 green chilies
    - 1 red chili
    - 2-3 tbsp oil
    - 1 sprig curry leaves
    - pinch hing
- roast and powder:
    - 3/4 tbsp chana dal
    - 3/4 tbsp urad dal
    - 2-3 red chilies
    - 1 tbsp coriander seeds
    - 1/2 tbsp cumin
    - 1/2 tsp mustard seeds
    - 1/4 tsp methi seeds
    - 1/4 tsp black pepper
    - pinch hing
    - 1 1/2 tbsp sesame seeds
    - 2-3 tbsp dried coconut

**Instructions:**

1.  Soak tamarind in 1/2 cup of water and add jaggery. When it turns soft, squeeze it and extract juice.
    
2.  Dry roast and powder in a blender.
    
3.  Roast tempering in oil.
    
4.  Add turmeric and salt. Stir and let cook untilslightly thick.
    
5.  Pour in tamarind and jaggery.
    
6.  Add powder and cook on medium heat until it thickens.
    
7.  Add oil.
    
8.  Add to rice and let absorb for 30 minutes.