**Ingredients:**

- Basmati rice
- Green peas
- Carrots
- Potatoes
- Tomatoes
- Peanuts
- Cumin seeds
- Black mustard seeds
- Cloves
- Cinnamon stick
- A bit of turmeric
- Garam masala
- Grated ginger

**Instructions:**

1.  Steam the vegetables.
2.  Add with a lot of butter to cooked basmati rice.