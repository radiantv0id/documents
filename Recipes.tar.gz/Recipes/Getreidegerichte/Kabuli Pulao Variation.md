**Ingredients**

- Red rice
- Grated carrots
- Raisins / figs
- Mung sprouts
- Spices