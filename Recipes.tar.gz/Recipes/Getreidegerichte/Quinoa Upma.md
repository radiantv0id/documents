**Ingredients for 2 people:**

- 1/3 cup quinoa
- 350 ml water
- ½ tsp black mustard seeds
- ½ tsp cumin seeds
- 1/3 cup cashews
- (1 tbsp urad dal / split yellow peas)
- 2,5 cm ginger
- 1-2 green chillies
- 1 spring onion
- 1 small red onion
- ¼ red capsicum
- ½ cup green peas
- 2 btsp grated coconut
- 1 tsp salt
- Juice of ½ lemon

**Instructions:**

1.  Bring quinoa to boil.
    
2.  Add capsicum and green peas.
    
3.  In a pan roast spices, chillies, onion and cashews.
    
4.  Add to quinoa.
    
5.  Add lemon juice and salt.