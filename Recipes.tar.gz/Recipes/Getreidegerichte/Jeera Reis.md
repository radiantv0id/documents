**Zutaten für 1 Person:**

- 3 handvoll Jasminreis
- einige Rosinen
- 1 TL Kreuzkümmelsamen
- 1 TL Kokosöl

**Zubereitung:**

1.  Jasminreis mit Kreuzkümmelsamen in Kokosöl anrösten, bis es schön duftet.
    
2.  Mit Wasser aufgeben, Rosinen und etwas Salz hinzugeben.
    
3.  15 Minuten köcheln lassen, ohne dabei umzurühern.
    
4.  Reis 20 Minuten ziehen lassen.