½ cup brown rice

1 tsp lemon zest

2 garlic cloves minced

1 ⅓ cup vegetable broth 330 ml

⅓ cup fresh oregano 8 g, chopped

⅓ cup fresh parsley 9 g, chopped